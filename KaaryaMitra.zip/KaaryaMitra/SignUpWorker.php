<?php


include('Databaseconn.php');
extract($_POST);

$encpaa = sha1($password);

$sql = "insert into signup_worker (fName,lName,email,mobile ,password,workType,AddressOne,AddressTwo,state,city,pincode) values
 ('$fname','$lname','$email','$mobile','$encpaa ','$worktype','$addressOne','$addressTwo','$city','$state','$pincode')";


 $result = mysqli_query($conn,$sql);


 if($result)
    {
        echo "OK";
    }
    else
   {
    echo  "Not Inserted";  
   }


?>