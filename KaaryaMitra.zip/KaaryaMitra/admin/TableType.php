<?php
	session_start();
	$image="";
	if(isset($_SESSION['email']) && isset($_SESSION['name']))
	{
		

	}
	else
	{
		header('location:index.html');
	}
?>


<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>KaaryaMitra</title>

<link rel="icon"  href="../image/KM2.jpg" />

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="../css/Profile.css"  />
    <linl rel="stylesheet" href="css/home.css" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
    
    
    <!-- For datatable -->
    
   
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    
    
    
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" ></script>
    
     
    
    
</head>
<body>
    

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div id="dismiss">
                <i class="fas fa-arrow-left"></i>
            </div>

            <div class="sidebar-header">
                <h3><img src="../image/KM2.jpg"  class="text-center" style="height: 40px;width: 80px;
    border-radius: 50%" /><span style="color: blue">Kaarya</span><span  style="color:red">Mintra</span></h3>
            </div>

            <ul class="list-unstyled components">
                <h5><img src="../image/profile.svg"  class="smallProfile"/><?php echo $_SESSION['name'];  ?></h5>
                
                <li class="active">
                    <a href="#">Home</a>
                </li>
                
                <li>
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">Users</a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="#rajmistri"  data-toggle="collapse" aria-expanded="false">Raj Mistri</a>
                            <ul class="collapse list-unstyled"    id="rajmistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                        </li>
                        
                        
                        <li>
                            <a href="#paintermistri"  data-toggle="collapse" aria-expanded="false">Painter</a>
                            <ul class="collapse list-unstyled"    id="paintermistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#plumbermistri"  data-toggle="collapse" aria-expanded="false">Plumber</a>
                            <ul class="collapse list-unstyled"    id="plumbermistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                        </li>
                        
                        <li>
                            <a href="#electrianMistri" data-toggle="collapse" aria-expanded="false" >Electrian</a>
                            <ul class="collapse list-unstyled"    id="electrianMistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                        
                        <li>
                            <a href="#weldermistri" data-toggle="collapse" aria-expanded="false">Welder</a>
                            <ul class="collapse list-unstyled"    id="weldermistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                        <li>
                            <a href="#sentingmistri" data-toggle="collapse" aria-expanded="false">Senting</a>
                            <ul class="collapse list-unstyled"    id="sentingmistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                        
                        <li>
                            <a href="#lohamistri" data-toggle="collapse" aria-expanded="false">Loha Mistri</a>
                            <ul class="collapse list-unstyled"    id="lohamistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                        
                        <li>
                            <a href="#marblemistri" data-toggle="collapse" aria-expanded="false">Marble</a>
                            <ul class="collapse list-unstyled"    id="marblemistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                        <li>
                            <a href="#forceilingmistri" data-toggle="collapse" aria-expanded="false">For Ceiling</a>
                            <ul class="collapse list-unstyled"    id="forceilingmistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                    </ul>
                </li>
                <li>
                    <a href="#">About</a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false">Pages</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="#">Page 1</a>
                        </li>
                        <li>
                            <a href="#">Page 2</a>
                        </li>
                        <li>
                            <a href="#">Page 3</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">Portfolio</a>
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
            </ul>

           
        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span></span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="logout.php">Logout</a>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </nav>

          
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12">
                        
                           
<div class="">
    
         <table class="table table-fluid" id="myTable">
                        <thead>
                        <tr>
                            <th>Sno</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Work Type</th>
                            <th>Subtype</th>
                            <th>Address</th>
                            <th>State</th>
                            <th>City</th>
                            <th>Pincode</th>
                            <th>Edit</th>
                            
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php
                                include('../Databaseconn.php');
                                
                                $sql = "select * from signup_worker where workType='Raj Mistri' ";
                            
                                $result = mysqli_query($conn,$sql);
                                $num = 1;
                                while($row  = mysqli_fetch_assoc($result))
                                {
                                    ?>
                            
                                    <tr>
                                        <td style="font-size:12px"><?php  echo $num; ?></td>
                                        <td style="font-size:12px"><?php echo $row['fname']," ".$row['lname'];  ?></td>
                                        <td style="font-size:12px"><?php echo $row['email']; ?></td>
                                        <td style="font-size:12px"><?php echo $row['mobile']; ?></td>
                                        <td style="font-size:12px"><?php echo $row['workType']; ?></td>
                                        <td style="font-size:12px"><?php  echo $row['subType']; ?></td>
                                        <td style="font-size:12px"><?php echo $row['AddressOne']; ?></td>
                                        <td style="font-size:12px"><?php echo $row['State']; ?></td>
                                        <td  style="font-size:12px"><?php echo $row['City']; ?></td>
                                        <td  style="font-size:12px"><?php echo $row['pincode']; ?></td>
                                        
                                        <td  style="font-size:12px">lop</td>
                                       
                                    
                                    </tr>
                            
                            <?php
                                    
                                    $num = $num + 1;
                                }
                                
                                
                            
                            
                            ?>
                        
                        </tbody>
                        </table>
    

</div>
                    
                    </div>
                
                </div>
            
            </div>
            
          
           

            
        </div>
    </div>

    <div class="overlay"></div>
    
    
    
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <!-- jQuery Custom Scroller CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });

            $('#dismiss, .overlay').on('click', function () {
                $('#sidebar').removeClass('active');
                $('.overlay').removeClass('active');
            });

            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').addClass('active');
                $('.overlay').addClass('active');
                $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });
    </script>
    
    
    
    
    
    


<script>
    $(document).ready( function () {
    $('#myTable').DataTable();
} );
    </script>
</body>
</html>