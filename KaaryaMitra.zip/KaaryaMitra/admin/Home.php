<?php
	session_start();
	$image="";
	if(isset($_SESSION['email']) && isset($_SESSION['name']))
	{
		

	}
	else
	{
		header('location:index.html');
	}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>KaaryaMitra</title>

<link rel="icon"  href="../image/KM2.jpg" />

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="css/style3.css">
    <link rel="stylesheet" href="../css/Profile.css"  />
    <linl rel="stylesheet" href="css/home.css" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
    
    
    
    


</head>

<body>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div id="dismiss">
                <i class="fas fa-arrow-left"></i>
            </div>

            <div class="sidebar-header">
                <h3><img src="../image/KM2.jpg"  class="text-center" style="height: 40px;width: 80px;
    border-radius: 50%" /><span style="color: blue">Kaarya</span><span  style="color:red">Mintra</span></h3>
            </div>

            <ul class="list-unstyled components">
                <h5><img src="../image/profile.svg"  class="smallProfile"/><?php echo $_SESSION['name'];  ?></h5>
                
                <li class="active">
                    <a href="#">Home</a>
                </li>
                
                <li>
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">Users</a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="#rajmistri"  data-toggle="collapse" aria-expanded="false">Raj Mistri</a>
                            <ul class="collapse list-unstyled"    id="rajmistri">
                                <li><a  href="RajMistri.php">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                        </li>
                        
                        
                        <li>
                            <a href="#paintermistri"  data-toggle="collapse" aria-expanded="false">Painter</a>
                            <ul class="collapse list-unstyled"    id="paintermistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#plumbermistri"  data-toggle="collapse" aria-expanded="false">Plumber</a>
                            <ul class="collapse list-unstyled"    id="plumbermistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                        </li>
                        
                        <li>
                            <a href="#electrianMistri" data-toggle="collapse" aria-expanded="false" >Electrian</a>
                            <ul class="collapse list-unstyled"    id="electrianMistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                        
                        <li>
                            <a href="#weldermistri" data-toggle="collapse" aria-expanded="false">Welder</a>
                            <ul class="collapse list-unstyled"    id="weldermistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                        <li>
                            <a href="#sentingmistri" data-toggle="collapse" aria-expanded="false">Senting</a>
                            <ul class="collapse list-unstyled"    id="sentingmistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                        
                        <li>
                            <a href="#lohamistri" data-toggle="collapse" aria-expanded="false">Loha Mistri</a>
                            <ul class="collapse list-unstyled"    id="lohamistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                        
                        <li>
                            <a href="#marblemistri" data-toggle="collapse" aria-expanded="false">Marble</a>
                            <ul class="collapse list-unstyled"    id="marblemistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                        <li>
                            <a href="#forceilingmistri" data-toggle="collapse" aria-expanded="false">For Ceiling</a>
                            <ul class="collapse list-unstyled"    id="forceilingmistri">
                                <li><a  href="#">Mistri</a></li>
                                <li><a  href="#">labour</a></li>
                            </ul>
                            
                        </li>
                        
                    </ul>
                </li>
                <li>
                    <a href="#">About</a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false">Pages</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="#">Page 1</a>
                        </li>
                        <li>
                            <a href="#">Page 2</a>
                        </li>
                        <li>
                            <a href="#">Page 3</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">Portfolio</a>
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
            </ul>

           
        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span></span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="logout.php">Logout</a>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </nav>

            <div class="container-fluid">
                <h3 class="text-center">Data Analysis</h3>
                <div class="row">
                    
                    <div class="col-xl-3 col-md-12 col-sm-12 card bg-success mb-3 divAll">
                    
                        <h3 class="text-center">Total Users</h3>
                        
                        <?php 
                            include('../Databaseconn.php');
                        
                            $sql = "SELECT count(*) as usertotal FROM signupnormal";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                        
                            $sql = "SELECT count(*) as usertotal FROM signupsupervisor";
                            $res = mysqli_query($conn,$sql);
                          
                            while($row = mysqli_fetch_assoc($res))
                            {
                               $total = $total + intval($row['usertotal']);  
                            }
                        
                            $sql = "SELECT count(*) as usertotal FROM signup_worker";
                            $rest = mysqli_query($conn,$sql);
                            
                            while($row = mysqli_fetch_assoc($rest))
                            {
                               $total = $total + intval($row['usertotal']); 
                            }
                        

                        ?>
                        
                        <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                     <div class="col-xl-3 col-md-12 col-sm-12 card bg-primary mb-3 divAll">
                         
                         <h3 class="text-center">Total Fimaly Users</h3>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM signupnormal";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    </div>
                    
                    
                     <div class="col-xl-3 col-md-12 col-sm-12 card bg-warning mb-3 divAll">
                         
                         <h3 class="text-center">Total Worker</h3>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM signup_worker ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    </div>
                    
                    <div class="col-xl-3 col-md-12 col-sm-12 card bg-info mb-3 divAll">
                         
                         <h3 class="text-center">Total Supervisor</h3>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM signupsupervisor ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    </div>
                    
                </div>

            </div>
            
            
            <div class="container-fluid">
                <h5 class="text-center">Worker Analysis</h5>
                <div class="row">
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Painter </h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Painter' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Raj Mistri </h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Raj Mistri' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Plumber</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Pulmbar' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    
                    
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Electrician</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Electrician' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Carpenter</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Carpenter' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    
                    
                    
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Welder</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Welder' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    
                    
                   
                
                </div>
            
            
            </div>
            
            
            
            <div class="container-fluid">
                <h6 class="text-center">Sub-Category</h6>
            <div class="row">
               <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Painter (Mistri)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Painter'  and subType='Mistri' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                   <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Painter (Labour)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Painter' and subType='Labour' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                    <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Raj Mistri (Mistri)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Raj Mistri' and subType='Mistri' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                    <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Raj Mistri (Labour)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Raj Mistri' and subType='Labour' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                    <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Pulmbar (Mistri)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Pulmbar' and subType='Mistri' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                
                    <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Pulmbar (Labour)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Pulmbar' and subType='Labour' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                    
                     <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Electrician (Mistri)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Electrician' and subType='Mistri' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                
                
                     <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Electrician (Labour)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Electrician' and subType='Labour' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                
                
                    <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Carpenter (Mistri)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Carpenter' and subType='Mistri' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                
                
                    <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Carpenter (Labour)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Carpenter' and subType='Labour' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                
                    <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAlldivAll">
                        
                        <h6 class="text-center">Welder (Mistri)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Welder' and subType='Mistri' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                
                    <div class="col-xl-1 col-md-6 col-sm-6 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Welder (Labour)</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signup_worker where workType='Welder' and subType='Labour' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                
                
            </div>
            
            </div>
            
            
            <div class="container-fluid">
                <h6 class="text-center">Supervisior Data Analysis</h6>
                 <div class="row">
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Painter </h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signupsupervisor where workType='Painter' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Raj Mistri </h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signupsupervisor where workType='Raj Mistri' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Plumber</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signupsupervisor where workType='Pulmbar' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    
                    
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Electrician</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signupsupervisor where workType='Electrician' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Carpenter</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signupsupervisor where workType='Carpenter' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    
                    
                    
                    <div class="col-xl-2 col-md-12 col-sm-12 bg-warning mb-3 divAll">
                        
                        <h6 class="text-center">Welder</h6>
                        <?php
                        
                        
                            $sql = "SELECT count(*) as usertotal FROM  signupsupervisor where workType='Welder' ";
                            $result = mysqli_query($conn,$sql);
                            $total = 0;
                            while($row = mysqli_fetch_assoc($result))
                            {
                               $total = intval($row['usertotal']); 
                            }
                         
                         
                         ?>
                         
                         <h1 class="text-center"><?php echo $total; ?></h1>
                    
                    </div>
                    
                    
                    
                   
                
                </div>
            
            
            </div>

           

            
        </div>
    </div>

    <div class="overlay"></div>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <!-- jQuery Custom Scroller CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });

            $('#dismiss, .overlay').on('click', function () {
                $('#sidebar').removeClass('active');
                $('.overlay').removeClass('active');
            });

            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').addClass('active');
                $('.overlay').addClass('active');
                $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });
    </script>
    
    
    

</body>

</html>