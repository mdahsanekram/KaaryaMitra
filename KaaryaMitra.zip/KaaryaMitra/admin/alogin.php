<?php

    include('../Databaseconn.php');

    extract($_POST);

    $encpass = sha1($password);
    
    $sql = "select email,name from admin where email='$email' and password='$encpass' ";

    $result = mysqli_query($conn,$sql);

    if(mysqli_num_rows($result) == 1)
    {
        while($row = mysqli_fetch_assoc($result))
        {
            $email = $row['email'];
            $name = $row['name'];
            session_start();
            $_SESSION['email'] = $email;
            $_SESSION['name']= $name;
        }
        echo "success";
        
        
    }
    else
    {
        echo "invalid";
    }

?>