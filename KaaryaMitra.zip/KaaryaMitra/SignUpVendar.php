<?php


include('Databaseconn.php');
extract($_POST);
$encpaa = sha1($password);

//echo $fname." ".$lname." ".$email." ".$mobile." ".$password." ".$addressOne." ".$adddressTwo." ".$Ggenstate." ".$city." ".$pincode; 
$sql = "insert into signupsupervisor (fName,lName,email,mobile,password,Add1,Add2,state,city,zip) values
 ('$fname','$lname','$email','$mobile','$encpaa','$addressOne','$adddressTwo','$Ggenstate','$city','$pincode')";


 $result = mysqli_query($conn,$sql);


 if($result)
    {
       echo "OK";
    }
    else
   {
    echo  "Not Inserted";  
   }


?>