<?php
    include('Databaseconn.php');


    $sql = "select * from signupnormal";

    $res = mysqli_query($conn,$sql);

    while($row=mysqli_fetch_assoc($res))
    {
        echo $row['fname'];
    }

    echo "hello kilo";



?>