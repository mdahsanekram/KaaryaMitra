<?php

include('DatabaseConn.php');
extract($_POST);

if(isset($_POST['mobile']))
{
		$emobile = $_POST['mobile'];
	
		$query = "select mobile from `signupnormal` where mobile='$emobile' ";
	
		$result = $conn->query($query);
		$num =  $result->num_rows;
		if($num==1)
		{
			echo "Mobile Number is already exites";
		}
		else
		{
			echo "Mobile success";
		}	
}




if(isset($_POST['email']))
{
		$eemail = $_POST['email'];
		$query = "select email from `signupnormal` where email='$eemail' ";
		$result = $conn->query($query);
		$num =  $result->num_rows;
		if($num==1)
		{
			echo "Email is already exites";
		}
		else
		{
			echo "Email success";
		}	
		
}
	
	
	



?>