<?php
	session_start();
	$workType = "";
    $id = "";
    $fname = "";
    $lname= "";
    $email= "";
    $mobile= "";
    $addressOne = "";
    $addressTwo = "";
    $state = "";
    $city="";
    $pincode="";
    $image = "";

    include('DatabaseConn.php');
	if(isset($_SESSION['usermobile']) && isset($_SESSION['username']))
	{
		$smobileNo = $_SESSION['usermobile'];
        $sql = "select * from signup_worker where mobile='$smobileNo' ";  
       
        $res = mysqli_query($conn,$sql);
        while($row = mysqli_fetch_assoc($res))
        {
            $id = $row['id'];
            $fname = $row['fname'];
            $lname= $row['lname'];
            $email=$row['email'];
            $mobile=$row['mobile'];
            $workType=$row['workType'];
            $addressOne=$row['AddressOne'];
            $addressTwo=$row['AddressTwo'];
            $state = $row['State'];
            $city = $row['City'];
            $pincode = $row['pincode'];
            $image = $row['proimage'];
        }
		
	}
	else
	{
		header('location:index.html');
	}


   // User upload image section
	if(isset($_POST['submit']))
	{
		$img2 = 'WorkerImage/'.$smobileNo.'.jpg';
		$img = $smobileNo.'.jpg';
		$sql = "update `signup_worker` set proimage='$img2' WHERE mobile='$smobileNo' ";
		//$insert = "insert into images (name,imagename) values ('$name','$img') ";
		if(mysqli_query($conn,$sql))
		{
			move_uploaded_file($_FILES['profileImage']['tmp_name'],"WorkerImage/$img");
			header('location:Profile.php');
		}
		else
		{
			echo "<script>alert('image Does not is uploaded To folder ')</script>";
		}
	}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <title>KaaryaMitra</title>

<link rel="icon"  href="image/KM2.jpg" />
<link rel="stylesheet" href="css/index.css"  />
<link rel="stylesheet" href="css/Profile.css"  />
    
      
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="css/style3.css">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

</head>
    

<body>
    <div class="bodyFull">

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div id="dismiss">
                <i class="fas fa-arrow-left"></i>
            </div>

            <div class="sidebar-header">
                <h3><img src="image/KM2.jpg"  class="navbarLogo  text-center" /><span style="color: blue">Kaarya</span><span  style="color:red">Mintra</span></h3>
            </div>

            <ul class="list-unstyled components">
                
                
                
                    
                    <?php  
                    
                        if($image!=null)
                        {
                            ?>
                           <h5><img src="<?php echo $image; ?>" class="smallProfile"/><?php echo $_SESSION['username'];  ?></h5>
                    <?php
                            
                        }
                    else
                    {
                        ?>
                        <h5><img src="image/profile.svg"  class="smallProfile"/>';
                        <?php echo $_SESSION['username']; ?></h5>
                        
                       
                   <?php
                    }
                    
                    
                    ?>
                    
                    
                <li>
                    <a href="Home.php">Home</a>
                    <a class="active" href="Profile.php">Profile</a>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false">Feedback</a>
                    
                </li>
                <li>
                    <a href="logout.php">Logout</a>
                </li>
                
            </ul>

            
        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span></span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>
                    
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="#">Notofication</a>
                            </li>
                            
                            <li class="nav-item active">
                                <a class="nav-link" href="logout.php">Logout</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

            <!-- Main Section start here -->
                
            
            <h3 class="text-center">User Details</h3>
            <div class="container-fluid">
					<div class="row">
                        
                    <div class="col-xl-4 col-md-12 col-sm-12 image">
						<div class="imageDiv">
                           <!-- <img src="image/profile.svg"  class="userProfile"  />  -->
                            
                            <form action="Profile.php" method="post" enctype="multipart/form-data" >
							<?php
							if($image!=null)
							{
							?>
								<img src="<?php echo $image; ?>" onclick="triggerClick()" id="profiledisplay" class="userProfile"   /><br>
							
							<?php
							}
							else
							{
								echo '<img src="image/profile.svg" onclick="triggerClick()" id="profiledisplay"  class="userProfile"  /><br>';
							}
							
							?>
							
							<input type="file" name="profileImage" onchange="displayImage(this)" id="profileImage" style="display:none;">
							
                                
                                <button type="submit" name="submit" class="btn btn-primary  setPhoto">Set Photo</button>

							</form>
                        
                        
                        </div>
                        
                        <!--<button class="btn btn-primary  setPhoto">Set Photo</button>  -->
                        
                    
                        
					</div>
					
					
                        
                        
                        
                        
                        
                        
					<div class="col-xl-8 col-md-12 col-sm-12" >
                        <table align="center">
                                    <tr><td>Name</td><td><?php echo $fname.' '.$lname  ?></td></tr>
                                    <tr><td>Mobile</td><td><?php echo $mobile; ?></td></tr>
                                    <tr><td>Email</td><td><?php echo $email; ?></td></tr>
                                    <tr><td>Address 1</td><td><?php echo $addressOne; ?></td></tr>
                                    <tr><td>Address 2</td><td><?php echo $addressTwo; ?></td></tr>
                                    <tr><td>State</td><td><?php echo $state; ?></td></tr>
                                    <tr><td>City</td><td><?php echo $city; ?></td></tr>
                                    <tr><td>Pincode</td><td><?php echo $pincode; ?></td></tr>

                                </table>
                        
                    
        
                        
                        <div class="row">
                            
                            <div class="col-xl-4 col-md-12 col-sm-12">
                            
                            <button class="btn btn-warning  text-center addharPass"   data-toggle="modal" data-target="#editModal"  onclick="editData('<?php  echo  $id;?>')">Edit</button> 
                            </div>
                            
                             <div class="col-xl-4 col-md-12 col-sm-12">
                            <button  class="btn btn-primary  text-center addharPass"   data-toggle="modal" data-target="#passwordChange">Change Password</button>
                            
                            <p id="passwordChMess"  class="text-center"></p>
                            </div>
                            
                            
                             <div class="col-xl-4 col-md-12 col-sm-12">
                        
                         <button  class="btn btn-primary  text-center addharPass">Add Adhar Card Numbar</button>
                            
                            </div>
                        
                        </div>
                        
                        
					
					</div>
					
					
					</div>
					
				</div>
            
            
            
            
            <!-- Old Wala -->
            
            
            
        </div>
    </div>

    <div class="overlay">  </div>
</div>
    
  
<!-- Modal For Edit User  -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title  text-center" id="exampleModalLabel">Edit Profile</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
<form>
<div class="form-group">
    <input type="hidden" class="form-control" id="update_id" >
</div>
    
    
<div class="form-group">
    <input type="text" class="form-control" id="update_fname" placeholder="Fname">
  </div>
    
    
<div class="form-group">
    <input type="text" class="form-control" id="update_lname" placeholder="Lname">
  </div>

    
   
<div class="form-group">
    <input type="email" class="form-control" id="update_email" placeholder="Email">
  </div>

  
<div class="form-group">
    <input type="number" class="form-control" id="update_mobile" placeholder="Mobile">
  </div>

     <div class="form-group">
                  <label for="inputState">Work Type</label>
                  <select id="update_workType" class="form-control">
                    <option></option>
                    <option value="Raj Mistri">Raj Mistri</option>
                    <option value="Penter">Penter</option>
                     <option value="Pulmbar">Pulmbar</option>
                     <option value="Badhai">Badhai</option>
                  </select>
     </div>
	 
	 
	  <div class="form-group">
                  <label for="inputState">Sub-Category</label>
                  <select id="update_subWork" class="form-control">
                     <option></option>
                    <option value="Mistri">Mistri</option>
                    <option value="Labour">Labour</option>
                     
                  </select>
     </div>
	 
	 
	 
    
    <div class="form-group">
    <input type="text" class="form-control" id="update_address1" placeholder="Address1">
  </div>
    
    
    <div class="form-group">
    <input type="text" class="form-control" id="update_address2" placeholder="Address2">
  </div>
    
    
    <div class="form-group">
    <input type="text" class="form-control" id="update_state" placeholder="state">
  </div>
    
    <div class="form-group">
    <input type="text" class="form-control" id="update_city" placeholder="City">
  </div>
    
    <div class="form-group">
    <input type="text" class="form-control" id="update_Pincode" placeholder="Pincode">
  </div>
    
    

</form>
              
          
      </div>
        
        
        
      <div class="modal-footer">
          <button type="button" class="btn btn-primary" onclick="saveChnage()">Save changes</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
        
    
    
    

<!-- Change password start-->	

<div class="modal" id="passwordChange">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Change Password</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="form-group">
			<input type="password" name="" id="password" class="form-control" placeholder="Enter the new Password">
		</div>
		
		 <div class="form-group">
			<input type="password" name="" id="cpassword" class="form-control" placeholder="Enter the confirm password">
        
        <p id="passwordDonMat"  class="text-center"></p>
		</div>
		
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
		 <button type="button" class="btn btn-success" data-dismiss="modal" onclick="changePassword('<?php  echo  $id;?>')">Set Password</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		<input type="hidden" name="" id="hidden_user_id" />
      </div>

    </div>
  </div>
</div>



    
    
    
    
    
    
    
    
    <!-- jQuery CDN - Slim version (=without AJAX) -->
      <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <!-- jQuery Custom Scroller CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $("#sidebar").mCustomScrollbar({
                theme: "minimal"
            });

            $('#dismiss, .overlay').on('click', function () {
                $('#sidebar').removeClass('active');
                $('.overlay').removeClass('active');
            });

            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').addClass('active');
                $('.overlay').addClass('active');
                $('.collapse.in').toggleClass('in');
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });
    </script>
</body>


    
    

    
<script>
function editData(wokID) 
{
    //alert(wokID);
    $(document).ready(function(){
        
         $.ajax({
               
                url:"EditProfileWorker.php",
                type:"post",
                data:{editWorkerId:wokID},
                success:function(data,status)
                {
                    
                    var user = JSON.parse(data);
                    $('#update_id').val(user.id);
                    $('#update_fname').val(user.fname);
                    $('#update_lname').val(user.lname);
                    $('#update_email').val(user.email);
                    $('#update_mobile').val(user.mobile);
                    $('#update_workType').val(user.workType);
                    $('#update_subWork').val(user.subType);
                    $('#update_address1').val(user.AddressOne);
                    $('#update_address2').val(user.AddressTwo);
                    $('#update_state').val(user.State);
                    $('#update_city').val(user.City);
                    $('#update_Pincode').val(user.pincode);
                   
                }
             
             
             
                
            });
        
       
        
    });
}
    
 
function saveChnage()
{
    $(document).ready(function(){
        let eid=$('#update_id').val();
        let fname=$('#update_fname').val();
		let lname=$('#update_lname').val();
        let email=$('#update_email').val();
		let mobile=$('#update_mobile').val();
        let workType=$('#update_workType').val();
        let subType=$('#update_subWork').val();
        let addressOne=$('#update_address1').val();
        let addressTwo=$('#update_address2').val();
        let state=$('#update_state').val();
        let city=$('#update_city').val();
        let pincode=$('#update_Pincode').val();

        
         $.ajax({
            
            url:"EditProfileWorker.php",
            type:"post",
            data:{chnid:eid,
            fname:fname,
              lname:lname,
              email:email,
              mobile:mobile,
              workType:workType,
              subType:subType,    
              addressOne:addressOne,
              addressTwo:addressTwo,
              city:city,
              state:state,
              pincode:pincode},
            success:function(data,status)
            {
                if(data=="ok")
                {
                    location.reload(true);
                }
                else
                {
                    alert("Not updated "+data);
                }
            }
            
        });
        
        
        
    });
}
    
</script>
    
<script>
    
function changePassword(pid)
{
    let val = 0;
    let pass=$('#password').val();
    let cpass=$('#cpassword').val();
    if(pass!=cpass)
    {
        $('#passwordDonMat').html('Password Must be Same...');
        $('#passwordDonMat').css('color','red');
        val =1;
        
    }
    
    if(val==0)
    {
    
        $.ajax({

            url:"EditProfileWorker.php",
            type:"post",
            data:{
            pid:pid,
            newpass:pass},
            success:function(data,status)
            {
                $('#passwordChMess').html('Password Changed Successfully..');
                $('#passwordChMess').css('color','green');
            }

        });
    }
   
}
    
</script>
    
    

<script>

    function triggerClick(){

         document.querySelector("#profileImage").click();
    }

    function displayImage(e){
        if(e.files[0]){
            var reader = new FileReader();
            
            reader.onload = function(e) {
                
                document.querySelector("#profiledisplay").setAttribute('src', e.target.result);

            }
            reader.readAsDataURL(e.files[0]);
        }
    }
</script>

</html>